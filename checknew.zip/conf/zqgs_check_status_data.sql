prompt Importing table zqgs_check_status...
set feedback off
set define off
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13200000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13470000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10140000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10290000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10230000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13660000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10940000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10430000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13410000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13180000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10240000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10990000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('11020000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('11170000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13160000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10460000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13140000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10910000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('11200000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10890000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10200000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10720000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13570000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10050000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10820000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('12710000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13500000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10380000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10620000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10970000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13130000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10090000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10180000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13420000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10830000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10060000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10160000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10270000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10280000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10330000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('11620000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('12360000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13590000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13690000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10040000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13710000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10420000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10170000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10710000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13730000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10500000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10080000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13230000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13510000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10780000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13120000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13400000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('12970000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13270000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('11100000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13080000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10760000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13370000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13110000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13720000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13260000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10680000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13090000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10900000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13170000', 0, null);

prompt Done.
