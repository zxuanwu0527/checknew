package com.szkingdom.submission.datacheck;

public interface DataConstants{
	public enum DataTye {
		VARCHAR, NUMBER, LONG;
	}
}

