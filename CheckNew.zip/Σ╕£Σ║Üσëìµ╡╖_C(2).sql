-----------------------------------------------------
-- Export file for user RZRQ                       --
-- Created by Administrator on 2018/8/22, 11:16:36 --
-----------------------------------------------------

spool 1369_C_2.log

prompt
prompt Creating table SC_C01_14120000
prompt ==============================
prompt
create table RZRQ.SC_C01_14120000
(
  ZQGSDM    VARCHAR2(255),
  YYBDM     VARCHAR2(255),
  KHDM      VARCHAR2(255),
  KHKHRQ    VARCHAR2(255),
  KHZXRQ    VARCHAR2(255),
  KHMC      VARCHAR2(255),
  KHLX      VARCHAR2(255),
  KHZT      VARCHAR2(255),
  ZJLX1     VARCHAR2(255),
  ZJHM1     VARCHAR2(255),
  ZJYXQJZR1 VARCHAR2(255),
  ZJLX2     VARCHAR2(255),
  ZJHM2     VARCHAR2(255),
  ZJYXQJZR2 VARCHAR2(255),
  KHGJ      VARCHAR2(255),
  KHXL      VARCHAR2(255),
  KHZY      VARCHAR2(255),
  FRDB      VARCHAR2(255),
  FRDBZJHM  VARCHAR2(255),
  JBR       VARCHAR2(255),
  JBRZJHM   VARCHAR2(255),
  ZCDZ      VARCHAR2(255),
  LXDZ      VARCHAR2(255),
  YZBM      VARCHAR2(255),
  LXDH      VARCHAR2(255),
  SJHM      VARCHAR2(255),
  DZYX      VARCHAR2(255),
  SJRQ      VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C01_14120000 to KRCS;

prompt
prompt Creating table SC_C01_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C01_14120000_Q
(
  ZQGSDM    VARCHAR2(255),
  YYBDM     VARCHAR2(255),
  KHDM      VARCHAR2(255),
  KHKHRQ    VARCHAR2(255),
  KHZXRQ    VARCHAR2(255),
  KHMC      VARCHAR2(255),
  KHLX      VARCHAR2(255),
  KHZT      VARCHAR2(255),
  ZJLX1     VARCHAR2(255),
  ZJHM1     VARCHAR2(255),
  ZJYXQJZR1 VARCHAR2(255),
  ZJLX2     VARCHAR2(255),
  ZJHM2     VARCHAR2(255),
  ZJYXQJZR2 VARCHAR2(255),
  KHGJ      VARCHAR2(255),
  KHXL      VARCHAR2(255),
  KHZY      VARCHAR2(255),
  FRDB      VARCHAR2(255),
  FRDBZJHM  VARCHAR2(255),
  JBR       VARCHAR2(255),
  JBRZJHM   VARCHAR2(255),
  ZCDZ      VARCHAR2(255),
  LXDZ      VARCHAR2(255),
  YZBM      VARCHAR2(255),
  LXDH      VARCHAR2(255),
  SJHM      VARCHAR2(255),
  DZYX      VARCHAR2(255),
  SJRQ      VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C01_14120000_Q to KRCS;

prompt
prompt Creating table SC_C01_14120000_Z
prompt ================================
prompt
create table RZRQ.SC_C01_14120000_Z
(
  ZQGSDM    VARCHAR2(255),
  YYBDM     VARCHAR2(255),
  KHDM      VARCHAR2(255),
  KHKHRQ    VARCHAR2(255),
  KHZXRQ    VARCHAR2(255),
  KHMC      VARCHAR2(255),
  KHLX      VARCHAR2(255),
  KHZT      VARCHAR2(255),
  ZJLX1     VARCHAR2(255),
  ZJHM1     VARCHAR2(255),
  ZJYXQJZR1 VARCHAR2(255),
  ZJLX2     VARCHAR2(255),
  ZJHM2     VARCHAR2(255),
  ZJYXQJZR2 VARCHAR2(255),
  KHGJ      VARCHAR2(255),
  KHXL      VARCHAR2(255),
  KHZY      VARCHAR2(255),
  FRDB      VARCHAR2(255),
  FRDBZJHM  VARCHAR2(255),
  JBR       VARCHAR2(255),
  JBRZJHM   VARCHAR2(255),
  ZCDZ      VARCHAR2(255),
  LXDZ      VARCHAR2(255),
  YZBM      VARCHAR2(255),
  LXDH      VARCHAR2(255),
  SJHM      VARCHAR2(255),
  DZYX      VARCHAR2(255),
  SJRQ      VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C01_14120000_Z to KRCS;

prompt
prompt Creating table SC_C02_14120000
prompt ==============================
prompt
create table RZRQ.SC_C02_14120000
(
  ZQGSDM    VARCHAR2(255),
  KHDM      VARCHAR2(255),
  HTQXMS    VARCHAR2(255),
  HTZT      VARCHAR2(255),
  HTHM      VARCHAR2(255),
  HTQSRQ    VARCHAR2(255),
  HTZZRQ    VARCHAR2(255),
  XYJBDM    VARCHAR2(255),
  RZCSBZJBL VARCHAR2(255),
  RQCSBZJBL VARCHAR2(255),
  SXED      VARCHAR2(255),
  RZSX      VARCHAR2(255),
  RQSX      VARCHAR2(255),
  SFHMDKH   VARCHAR2(255),
  SFFXKH    VARCHAR2(255),
  SFXZJYKH  VARCHAR2(255),
  SFXSGKH   VARCHAR2(255),
  SFDJGKH   VARCHAR2(255),
  SJRQ      VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C02_14120000 to KRCS;

prompt
prompt Creating table SC_C02_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C02_14120000_Q
(
  ZQGSDM    VARCHAR2(255),
  KHDM      VARCHAR2(255),
  HTQXMS    VARCHAR2(255),
  HTZT      VARCHAR2(255),
  HTHM      VARCHAR2(255),
  HTQSRQ    VARCHAR2(255),
  HTZZRQ    VARCHAR2(255),
  XYJBDM    VARCHAR2(255),
  RZCSBZJBL VARCHAR2(255),
  RQCSBZJBL VARCHAR2(255),
  SXED      VARCHAR2(255),
  RZSX      VARCHAR2(255),
  RQSX      VARCHAR2(255),
  SFHMDKH   VARCHAR2(255),
  SFFXKH    VARCHAR2(255),
  SFXZJYKH  VARCHAR2(255),
  SFXSGKH   VARCHAR2(255),
  SFDJGKH   VARCHAR2(255),
  SJRQ      VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C02_14120000_Q to KRCS;

prompt
prompt Creating table SC_C02_14120000_Z
prompt ================================
prompt
create table RZRQ.SC_C02_14120000_Z
(
  ZQGSDM    VARCHAR2(255),
  KHDM      VARCHAR2(255),
  HTQXMS    VARCHAR2(255),
  HTZT      VARCHAR2(255),
  HTHM      VARCHAR2(255),
  HTQSRQ    VARCHAR2(255),
  HTZZRQ    VARCHAR2(255),
  XYJBDM    VARCHAR2(255),
  RZCSBZJBL VARCHAR2(255),
  RQCSBZJBL VARCHAR2(255),
  SXED      VARCHAR2(255),
  RZSX      VARCHAR2(255),
  RQSX      VARCHAR2(255),
  SFHMDKH   VARCHAR2(255),
  SFFXKH    VARCHAR2(255),
  SFXZJYKH  VARCHAR2(255),
  SFXSGKH   VARCHAR2(255),
  SFDJGKH   VARCHAR2(255),
  SJRQ      VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C02_14120000_Z to KRCS;

prompt
prompt Creating table SC_C03_14120000
prompt ==============================
prompt
create table RZRQ.SC_C03_14120000
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  ZHLX   VARCHAR2(255),
  SCDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  ZDZT   VARCHAR2(255),
  XWDM   VARCHAR2(255),
  YHDM   VARCHAR2(255),
  ZHZT   VARCHAR2(255),
  KHRQ   VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C03_14120000 to KRCS;

prompt
prompt Creating table SC_C03_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C03_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  ZHLX   VARCHAR2(255),
  SCDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  ZDZT   VARCHAR2(255),
  XWDM   VARCHAR2(255),
  YHDM   VARCHAR2(255),
  ZHZT   VARCHAR2(255),
  KHRQ   VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C03_14120000_Q to KRCS;

prompt
prompt Creating table SC_C03_14120000_Z
prompt ================================
prompt
create table RZRQ.SC_C03_14120000_Z
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  ZHLX   VARCHAR2(255),
  SCDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  ZDZT   VARCHAR2(255),
  XWDM   VARCHAR2(255),
  YHDM   VARCHAR2(255),
  ZHZT   VARCHAR2(255),
  KHRQ   VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C03_14120000_Z to KRCS;

prompt
prompt Creating table SC_C04_14120000
prompt ==============================
prompt
create table RZRQ.SC_C04_14120000
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  BZ     VARCHAR2(255),
  ZJYE   VARCHAR2(255),
  DJZJ   VARCHAR2(255),
  WDZZJ  VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C04_14120000 to KRCS;

prompt
prompt Creating table SC_C04_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C04_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  BZ     VARCHAR2(255),
  ZJYE   VARCHAR2(255),
  DJZJ   VARCHAR2(255),
  WDZZJ  VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C04_14120000_Q to KRCS;

prompt
prompt Creating table SC_C05_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C05_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  BZ     VARCHAR2(255),
  FSRQ   VARCHAR2(255),
  FSSJ   VARCHAR2(255),
  BDLB   VARCHAR2(255),
  ZJLSH  VARCHAR2(255),
  ZY     VARCHAR2(255),
  FSJE   VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C05_14120000_Q to KRCS;

prompt
prompt Creating table SC_C05_14120000_Z
prompt ================================
prompt
create table RZRQ.SC_C05_14120000_Z
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  BZ     VARCHAR2(255),
  FSRQ   VARCHAR2(255),
  FSSJ   VARCHAR2(255),
  BDLB   VARCHAR2(255),
  ZJLSH  VARCHAR2(255),
  ZY     VARCHAR2(255),
  FSJE   VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C05_14120000_Z to KRCS;

prompt
prompt Creating table SC_C06_14120000
prompt ==============================
prompt
create table RZRQ.SC_C06_14120000
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  BZ     VARCHAR2(255),
  SCDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  ZQDM   VARCHAR2(255),
  ZQSL   VARCHAR2(255),
  WDZSL  VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C06_14120000 to KRCS;

prompt
prompt Creating table SC_C06_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C06_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  BZ     VARCHAR2(255),
  SCDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  ZQDM   VARCHAR2(255),
  ZQSL   VARCHAR2(255),
  WDZSL  VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C06_14120000_Q to KRCS;

prompt
prompt Creating table SC_C07_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C07_14120000_Q
(
  ZQGSDM   VARCHAR2(255),
  KHDM     VARCHAR2(255),
  BZ       VARCHAR2(255),
  SCDM     VARCHAR2(255),
  ZHDM     VARCHAR2(255),
  FSRQ     VARCHAR2(255),
  FSSJ     VARCHAR2(255),
  BDLB     VARCHAR2(255),
  FJYZQLSH VARCHAR2(255),
  ZY       VARCHAR2(255),
  ZQDM     VARCHAR2(255),
  BDSL     VARCHAR2(255),
  SJRQ     VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C07_14120000_Q to KRCS;

prompt
prompt Creating table SC_C07_14120000_Z
prompt ================================
prompt
create table RZRQ.SC_C07_14120000_Z
(
  ZQGSDM   VARCHAR2(255),
  KHDM     VARCHAR2(255),
  BZ       VARCHAR2(255),
  SCDM     VARCHAR2(255),
  ZHDM     VARCHAR2(255),
  FSRQ     VARCHAR2(255),
  FSSJ     VARCHAR2(255),
  BDLB     VARCHAR2(255),
  FJYZQLSH VARCHAR2(255),
  ZY       VARCHAR2(255),
  ZQDM     VARCHAR2(255),
  BDSL     VARCHAR2(255),
  SJRQ     VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C07_14120000_Z to KRCS;

prompt
prompt Creating table SC_C08_14120000
prompt ==============================
prompt
create table RZRQ.SC_C08_14120000
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  BZ     VARCHAR2(255),
  RZYE   VARCHAR2(255),
  GF     VARCHAR2(255),
  JYYJ   VARCHAR2(255),
  RZLX   VARCHAR2(255),
  QTFY   VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C08_14120000 to KRCS;

prompt
prompt Creating table SC_C08_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C08_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  BZ     VARCHAR2(255),
  RZYE   VARCHAR2(255),
  GF     VARCHAR2(255),
  JYYJ   VARCHAR2(255),
  RZLX   VARCHAR2(255),
  QTFY   VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C08_14120000_Q to KRCS;

prompt
prompt Creating table SC_C09_14120000
prompt ==============================
prompt
create table RZRQ.SC_C09_14120000
(
  ZQGSDM   VARCHAR2(255),
  KHDM     VARCHAR2(255),
  ZHDM     VARCHAR2(255),
  BZ       VARCHAR2(255),
  FSRQ     VARCHAR2(255),
  FSSJ     VARCHAR2(255),
  RZKCDJHM VARCHAR2(255),
  SCDM     VARCHAR2(255),
  ZQDM     VARCHAR2(255),
  CJJG     VARCHAR2(255),
  KCJE     VARCHAR2(255),
  CHJE     VARCHAR2(255),
  RZJE     VARCHAR2(255),
  RZLX     VARCHAR2(255),
  YQFX     VARCHAR2(255),
  WJXF     VARCHAR2(255),
  YJWFXF   VARCHAR2(255),
  YJYFXF   VARCHAR2(255),
  LJBZ     VARCHAR2(255),
  CDDQR    VARCHAR2(255),
  BZZ      VARCHAR2(255),
  SJRQ     VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C09_14120000 to KRCS;

prompt
prompt Creating table SC_C09_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C09_14120000_Q
(
  ZQGSDM   VARCHAR2(255),
  KHDM     VARCHAR2(255),
  ZHDM     VARCHAR2(255),
  BZ       VARCHAR2(255),
  FSRQ     VARCHAR2(255),
  FSSJ     VARCHAR2(255),
  RZKCDJHM VARCHAR2(255),
  SCDM     VARCHAR2(255),
  ZQDM     VARCHAR2(255),
  CJJG     VARCHAR2(255),
  KCJE     VARCHAR2(255),
  CHJE     VARCHAR2(255),
  RZJE     VARCHAR2(255),
  RZLX     VARCHAR2(255),
  YQFX     VARCHAR2(255),
  WJXF     VARCHAR2(255),
  YJWFXF   VARCHAR2(255),
  YJYFXF   VARCHAR2(255),
  LJBZ     VARCHAR2(255),
  CDDQR    VARCHAR2(255),
  BZZ      VARCHAR2(255),
  SJRQ     VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C09_14120000_Q to KRCS;

prompt
prompt Creating table SC_C10_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C10_14120000_Q
(
  ZQGSDM   VARCHAR2(255),
  KHDM     VARCHAR2(255),
  ZHDM     VARCHAR2(255),
  BZ       VARCHAR2(255),
  FSRQ     VARCHAR2(255),
  FSSJ     VARCHAR2(255),
  RZKCDJHM VARCHAR2(255),
  CHLSH    VARCHAR2(255),
  CHLX     VARCHAR2(255),
  QZPCBZ   VARCHAR2(255),
  ZY       VARCHAR2(255),
  CHJE     VARCHAR2(255),
  SJRQ     VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C10_14120000_Q to KRCS;

prompt
prompt Creating table SC_C10_14120000_Z
prompt ================================
prompt
create table RZRQ.SC_C10_14120000_Z
(
  ZQGSDM   VARCHAR2(255),
  KHDM     VARCHAR2(255),
  ZHDM     VARCHAR2(255),
  BZ       VARCHAR2(255),
  FSRQ     VARCHAR2(255),
  FSSJ     VARCHAR2(255),
  RZKCDJHM VARCHAR2(255),
  CHLSH    VARCHAR2(255),
  CHLX     VARCHAR2(255),
  QZPCBZ   VARCHAR2(255),
  ZY       VARCHAR2(255),
  CHJE     VARCHAR2(255),
  SJRQ     VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C10_14120000_Z to KRCS;

prompt
prompt Creating table SC_C11_14120000
prompt ==============================
prompt
create table RZRQ.SC_C11_14120000
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  BZ     VARCHAR2(255),
  SCDM   VARCHAR2(255),
  ZQDM   VARCHAR2(255),
  RQSL   VARCHAR2(255),
  RQJE   VARCHAR2(255),
  RQFY   VARCHAR2(255),
  QTFY   VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C11_14120000 to KRCS;

prompt
prompt Creating table SC_C11_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C11_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  BZ     VARCHAR2(255),
  SCDM   VARCHAR2(255),
  ZQDM   VARCHAR2(255),
  RQSL   VARCHAR2(255),
  RQJE   VARCHAR2(255),
  RQFY   VARCHAR2(255),
  QTFY   VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C11_14120000_Q to KRCS;

prompt
prompt Creating table SC_C12_14120000
prompt ==============================
prompt
create table RZRQ.SC_C12_14120000
(
  ZQGSDM   VARCHAR2(255),
  KHDM     VARCHAR2(255),
  ZHDM     VARCHAR2(255),
  BZ       VARCHAR2(255),
  FSRQ     VARCHAR2(255),
  FSSJ     VARCHAR2(255),
  RQKCDJHM VARCHAR2(255),
  SCDM     VARCHAR2(255),
  ZQDM     VARCHAR2(255),
  CJJG     VARCHAR2(255),
  KCSL     VARCHAR2(255),
  CHSL     VARCHAR2(255),
  RQSL     VARCHAR2(255),
  RQFY     VARCHAR2(255),
  YQFX     VARCHAR2(255),
  WJXF     VARCHAR2(255),
  YJWFXF   VARCHAR2(255),
  YJYFXF   VARCHAR2(255),
  LJBZ     VARCHAR2(255),
  CDDQR    VARCHAR2(255),
  BZZ      VARCHAR2(255),
  SJRQ     VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C12_14120000 to KRCS;

prompt
prompt Creating table SC_C12_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C12_14120000_Q
(
  ZQGSDM   VARCHAR2(255),
  KHDM     VARCHAR2(255),
  ZHDM     VARCHAR2(255),
  BZ       VARCHAR2(255),
  FSRQ     VARCHAR2(255),
  FSSJ     VARCHAR2(255),
  RQKCDJHM VARCHAR2(255),
  SCDM     VARCHAR2(255),
  ZQDM     VARCHAR2(255),
  CJJG     VARCHAR2(255),
  KCSL     VARCHAR2(255),
  CHSL     VARCHAR2(255),
  RQSL     VARCHAR2(255),
  RQFY     VARCHAR2(255),
  YQFX     VARCHAR2(255),
  WJXF     VARCHAR2(255),
  YJWFXF   VARCHAR2(255),
  YJYFXF   VARCHAR2(255),
  LJBZ     VARCHAR2(255),
  CDDQR    VARCHAR2(255),
  BZZ      VARCHAR2(255),
  SJRQ     VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C12_14120000_Q to KRCS;

prompt
prompt Creating table SC_C13_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C13_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  BZ     VARCHAR2(255),
  FSRQ   VARCHAR2(255),
  FSSJ   VARCHAR2(255),
  KCDJHM VARCHAR2(255),
  CHLSH  VARCHAR2(255),
  CHLX   VARCHAR2(255),
  QZPCBZ VARCHAR2(255),
  ZY     VARCHAR2(255),
  SCDM   VARCHAR2(255),
  ZQDM   VARCHAR2(255),
  CHSL   VARCHAR2(255),
  CHJE   VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C13_14120000_Q to KRCS;

prompt
prompt Creating table SC_C13_14120000_Z
prompt ================================
prompt
create table RZRQ.SC_C13_14120000_Z
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  BZ     VARCHAR2(255),
  FSRQ   VARCHAR2(255),
  FSSJ   VARCHAR2(255),
  KCDJHM VARCHAR2(255),
  CHLSH  VARCHAR2(255),
  CHLX   VARCHAR2(255),
  QZPCBZ VARCHAR2(255),
  ZY     VARCHAR2(255),
  SCDM   VARCHAR2(255),
  ZQDM   VARCHAR2(255),
  CHSL   VARCHAR2(255),
  CHJE   VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C13_14120000_Z to KRCS;

prompt
prompt Creating table SC_C14_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C14_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  BZ     VARCHAR2(255),
  SCDM   VARCHAR2(255),
  ZQDM   VARCHAR2(255),
  YQSL   VARCHAR2(255),
  YQHG   VARCHAR2(255),
  YQHL   VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C14_14120000_Q to KRCS;

prompt
prompt Creating table SC_C14_14120000_Z
prompt ================================
prompt
create table RZRQ.SC_C14_14120000_Z
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  BZ     VARCHAR2(255),
  SCDM   VARCHAR2(255),
  ZQDM   VARCHAR2(255),
  YQSL   VARCHAR2(255),
  YQHG   VARCHAR2(255),
  YQHL   VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C14_14120000_Z to KRCS;

prompt
prompt Creating table SC_C15_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C15_14120000_Q
(
  zqgsdm   VARCHAR2(255),
  khdm     VARCHAR2(255),
  bz       VARCHAR2(255),
  zjye     VARCHAR2(255),
  wdzzj    VARCHAR2(255),
  zqsz     VARCHAR2(255),
  qtdbwjz  VARCHAR2(255),
  rzfz     VARCHAR2(255),
  rqfz     VARCHAR2(255),
  zdwcdbbl VARCHAR2(255),
  wcdbbl   VARCHAR2(255),
  bzjkyye  VARCHAR2(255),
  bzz      VARCHAR2(255),
  sjrq     VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C15_14120000_Q to KRCS;

prompt
prompt Creating table SC_C16_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C16_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  BZ     VARCHAR2(255),
  SCDM   VARCHAR2(255),
  JYXW   VARCHAR2(255),
  FSRQ   VARCHAR2(255),
  FSSJ   VARCHAR2(255),
  WTLX   VARCHAR2(255),
  MMLB   VARCHAR2(255),
  ZQDM   VARCHAR2(255),
  ZQJC   VARCHAR2(255),
  CJJG   VARCHAR2(255),
  CJSL   VARCHAR2(255),
  CJJE   VARCHAR2(255),
  JYYJ   VARCHAR2(255),
  YHS    VARCHAR2(255),
  GHF    VARCHAR2(255),
  QTFY   VARCHAR2(255),
  WTLSH  VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C16_14120000_Q to KRCS;

prompt
prompt Creating table SC_C16_14120000_Z
prompt ================================
prompt
create table RZRQ.SC_C16_14120000_Z
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  BZ     VARCHAR2(255),
  SCDM   VARCHAR2(255),
  JYXW   VARCHAR2(255),
  FSRQ   VARCHAR2(255),
  FSSJ   VARCHAR2(255),
  WTLX   VARCHAR2(255),
  MMLB   VARCHAR2(255),
  ZQDM   VARCHAR2(255),
  ZQJC   VARCHAR2(255),
  CJJG   VARCHAR2(255),
  CJSL   VARCHAR2(255),
  CJJE   VARCHAR2(255),
  JYYJ   VARCHAR2(255),
  YHS    VARCHAR2(255),
  GHF    VARCHAR2(255),
  QTFY   VARCHAR2(255),
  WTLSH  VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C16_14120000_Z to KRCS;

prompt
prompt Creating table SC_C17_14120000
prompt ==============================
prompt
create table RZRQ.SC_C17_14120000
(
  ZQGSDM   VARCHAR2(255),
  KHDM     VARCHAR2(255),
  ZHDM     VARCHAR2(255),
  BZ       VARCHAR2(255),
  FSRQ     VARCHAR2(255),
  KCDJHM   VARCHAR2(255),
  QYRQDJHM VARCHAR2(255),
  SCDM     VARCHAR2(255),
  ZQDM     VARCHAR2(255),
  RQSL     VARCHAR2(255),
  BCLX     VARCHAR2(255),
  BCJE     VARCHAR2(255),
  BCSL     VARCHAR2(255),
  CHJE     VARCHAR2(255),
  CHSL     VARCHAR2(255),
  QYLSH    VARCHAR2(255),
  QYRZDJHM VARCHAR2(255),
  SJRQ     VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C17_14120000 to KRCS;

prompt
prompt Creating table SC_C17_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C17_14120000_Q
(
  ZQGSDM   VARCHAR2(255),
  KHDM     VARCHAR2(255),
  ZHDM     VARCHAR2(255),
  BZ       VARCHAR2(255),
  FSRQ     VARCHAR2(255),
  KCDJHM   VARCHAR2(255),
  QYRQDJHM VARCHAR2(255),
  SCDM     VARCHAR2(255),
  ZQDM     VARCHAR2(255),
  RQSL     VARCHAR2(255),
  BCLX     VARCHAR2(255),
  BCJE     VARCHAR2(255),
  BCSL     VARCHAR2(255),
  CHJE     VARCHAR2(255),
  CHSL     VARCHAR2(255),
  QYLSH    VARCHAR2(255),
  QYRZDJHM VARCHAR2(255),
  SJRQ     VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C17_14120000_Q to KRCS;

prompt
prompt Creating table SC_C17_14120000_Z
prompt ================================
prompt
create table RZRQ.SC_C17_14120000_Z
(
  ZQGSDM   VARCHAR2(255),
  KHDM     VARCHAR2(255),
  ZHDM     VARCHAR2(255),
  BZ       VARCHAR2(255),
  FSRQ     VARCHAR2(255),
  KCDJHM   VARCHAR2(255),
  QYRQDJHM VARCHAR2(255),
  SCDM     VARCHAR2(255),
  ZQDM     VARCHAR2(255),
  RQSL     VARCHAR2(255),
  BCLX     VARCHAR2(255),
  BCJE     VARCHAR2(255),
  BCSL     VARCHAR2(255),
  CHJE     VARCHAR2(255),
  CHSL     VARCHAR2(255),
  QYLSH    VARCHAR2(255),
  QYRZDJHM VARCHAR2(255),
  SJRQ     VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C17_14120000_Z to KRCS;

prompt
prompt Creating table SC_C18_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_C18_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  SCDM   VARCHAR2(255),
  GZLB   VARCHAR2(255),
  BZ     VARCHAR2(255),
  WYJE   VARCHAR2(255),
  GZBZ   VARCHAR2(255),
  BZZ    VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C18_14120000_Q to KRCS;

prompt
prompt Creating table SC_C18_14120000_Z
prompt ================================
prompt
create table RZRQ.SC_C18_14120000_Z
(
  ZQGSDM VARCHAR2(255),
  KHDM   VARCHAR2(255),
  SCDM   VARCHAR2(255),
  GZLB   VARCHAR2(255),
  BZ     VARCHAR2(255),
  WYJE   VARCHAR2(255),
  GZBZ   VARCHAR2(255),
  BZZ    VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_C18_14120000_Z to KRCS;


spool off
