prompt Importing table zqgs_check_status...
set feedback off
set define off
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10500000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10040000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10140000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10200000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10420000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10510000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10730000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10890000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('11200000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('12710000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13270000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13310000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10230000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13320000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10050000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10150000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10240000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10270000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10610000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10760000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10910000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('11300000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('12970000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13260000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13730000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10160000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10250000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10470000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10620000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10780000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10940000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('11100000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('11380000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10280000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('11020000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13370000', 0, null);
insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10080000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('11080000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('13480000', 0, null);

insert into zqgs_check_status (ZQGSDM, CHECKSTATUS, CHECKPROCESSOR)
values ('10830000', 0, null);
commit;
prompt Done.
