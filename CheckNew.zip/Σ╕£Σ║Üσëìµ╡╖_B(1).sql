-----------------------------------------------------
-- Export file for user RZRQ                       --
-- Created by Administrator on 2018/8/22, 10:59:55 --
-----------------------------------------------------

spool 1369_B.log

prompt
prompt Creating table SC_B01_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_B01_14120000_Q
(
  ZQGSDM  VARCHAR2(255),
  ZQGSMC  VARCHAR2(255),
  ZQGSJZB VARCHAR2(255),
  SJRQ    VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_B01_14120000_Q to KRCS;

prompt
prompt Creating table SC_B02_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_B02_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  ZHLX   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  KHRQ   VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_B02_14120000_Q to KRCS;

prompt
prompt Creating table SC_B03_14120000
prompt ==============================
prompt
create table RZRQ.SC_B03_14120000
(
  ZQGSDM VARCHAR2(255),
  ZHLX   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  ZQDM   VARCHAR2(255),
  ZQSL   VARCHAR2(255),
  WDZSL  VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_B03_14120000 to KRCS;

prompt
prompt Creating table SC_B03_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_B03_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  ZHLX   VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  ZQDM   VARCHAR2(255),
  ZQSL   VARCHAR2(255),
  WDZSL  VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_B03_14120000_Q to KRCS;

prompt
prompt Creating table SC_B04_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_B04_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  ZHDM   VARCHAR2(255),
  ZHLX   VARCHAR2(255),
  BZ     VARCHAR2(255),
  ZJYE   VARCHAR2(255),
  WDZJE  VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_B04_14120000_Q to KRCS;

prompt
prompt Creating table SC_B05_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_B05_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  SCDM   VARCHAR2(255),
  ZQDM   VARCHAR2(255),
  RZRQBD VARCHAR2(255),
  DBWBD  VARCHAR2(255),
  ZSL    VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_B05_14120000_Q to KRCS;

prompt
prompt Creating table SC_B06_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_B06_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  YHDM   VARCHAR2(255),
  YHMC   VARCHAR2(255),
  CGLX   VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_B06_14120000_Q to KRCS;

prompt
prompt Creating table SC_B07_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_B07_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  YYBDM  VARCHAR2(255),
  YYBMC  VARCHAR2(255),
  YYBDZ  VARCHAR2(255),
  ZJJDM  VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_B07_14120000_Q to KRCS;

prompt
prompt Creating table SC_B08_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_B08_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  FLLX   VARCHAR2(255),
  XFL    VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_B08_14120000_Q to KRCS;

prompt
prompt Creating table SC_B09_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_B09_14120000_Q
(
  ZQGSDM    VARCHAR2(255),
  XYJBDM    VARCHAR2(255),
  XYJBMC    VARCHAR2(255),
  RZCSBZJBL VARCHAR2(255),
  RZSXEDBZ  VARCHAR2(255),
  RQCSBZJBL VARCHAR2(255),
  RQSXEDBZ  VARCHAR2(255),
  BZZ       VARCHAR2(255),
  SJRQ      VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_B09_14120000_Q to KRCS;

prompt
prompt Creating table SC_B10_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_B10_14120000_Q
(
  ZQGSDM VARCHAR2(255),
  BZ     VARCHAR2(255),
  SCDM   VARCHAR2(255),
  ZQDM   VARCHAR2(255),
  QYDM   VARCHAR2(255),
  QYLX   VARCHAR2(255),
  ZYXX   VARCHAR2(255),
  QYBL   VARCHAR2(255),
  DJRQ   VARCHAR2(255),
  CQRQ   VARCHAR2(255),
  QYSSRQ VARCHAR2(255),
  QYLSH  VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_B10_14120000_Q to KRCS;

prompt
prompt Creating table SC_B10_14120000_Z
prompt ================================
prompt
create table RZRQ.SC_B10_14120000_Z
(
  ZQGSDM VARCHAR2(255),
  BZ     VARCHAR2(255),
  SCDM   VARCHAR2(255),
  ZQDM   VARCHAR2(255),
  QYDM   VARCHAR2(255),
  QYLX   VARCHAR2(255),
  ZYXX   VARCHAR2(255),
  QYBL   VARCHAR2(255),
  DJRQ   VARCHAR2(255),
  CQRQ   VARCHAR2(255),
  QYSSRQ VARCHAR2(255),
  QYLSH  VARCHAR2(255),
  SJRQ   VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_B10_14120000_Z to KRCS;

prompt
prompt Creating table SC_B11_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_B11_14120000_Q
(
  zqgsdm    VARCHAR2(255),
  bz        VARCHAR2(255),
  khzjye    VARCHAR2(255),
  khzyzj    VARCHAR2(255),
  khrqmczj  VARCHAR2(255),
  khwdzzj   VARCHAR2(255),
  khzqsz    VARCHAR2(255),
  khwdzzqsz VARCHAR2(255),
  khqtdbwjz VARCHAR2(255),
  khzzc     VARCHAR2(255),
  khrzfz    VARCHAR2(255),
  khrzje    VARCHAR2(255),
  khrzsxfy  VARCHAR2(255),
  khrzxf    VARCHAR2(255),
  khrzqtfy  VARCHAR2(255),
  khrqfz    VARCHAR2(255),
  khrqje    VARCHAR2(255),
  khrqsxfy  VARCHAR2(255),
  khrqfy    VARCHAR2(255),
  khrqqtfy  VARCHAR2(255),
  khbzjye   VARCHAR2(255),
  rzzybzj   VARCHAR2(255),
  rqzybzj   VARCHAR2(255),
  khzfz     VARCHAR2(255),
  ztwcdbbl  VARCHAR2(255),
  rzggl     VARCHAR2(255),
  rqggl     VARCHAR2(255),
  ztggl     VARCHAR2(255),
  sjrq      VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_B11_14120000_Q to KRCS;

prompt
prompt Creating table SC_B12_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_B12_14120000_Q
(
  ZQGSDM  VARCHAR2(255),
  BZ      VARCHAR2(255),
  QSRQ    VARCHAR2(255),
  ZZRQ    VARCHAR2(255),
  DBPMRJE VARCHAR2(255),
  DBPMCJE VARCHAR2(255),
  RZMRJE  VARCHAR2(255),
  MQHKJE  VARCHAR2(255),
  ZJHKJE  VARCHAR2(255),
  RZPCJE  VARCHAR2(255),
  RQMCJE  VARCHAR2(255),
  MQHQJE  VARCHAR2(255),
  HQHZJE  VARCHAR2(255),
  YQHZJE  VARCHAR2(255),
  RQPCJE  VARCHAR2(255),
  PTJYJE  VARCHAR2(255),
  XYJYJE  VARCHAR2(255),
  JYJEHJ  VARCHAR2(255),
  SJRQ    VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_B12_14120000_Q to KRCS;

prompt
prompt Creating table SC_B13_14120000_Q
prompt ================================
prompt
create table RZRQ.SC_B13_14120000_Q
(
  ZQGSDM   VARCHAR2(255),
  QSRQ     VARCHAR2(255),
  ZZRQ     VARCHAR2(255),
  BZ       VARCHAR2(255),
  RZLX     VARCHAR2(255),
  RQFY     VARCHAR2(255),
  YQFX     VARCHAR2(255),
  QTXFSR   VARCHAR2(255),
  KHWJXF   VARCHAR2(255),
  KHYJWFXF VARCHAR2(255),
  XFSRHJ   VARCHAR2(255),
  JYGF     VARCHAR2(255),
  PTJYYJ   VARCHAR2(255),
  XYJYYJ   VARCHAR2(255),
  YJHJ     VARCHAR2(255),
  PTYJL    VARCHAR2(255),
  XYYJL    VARCHAR2(255),
  ZTYJL    VARCHAR2(255),
  HZSXF    VARCHAR2(255),
  QTJYSR   VARCHAR2(255),
  JYSRHJ   VARCHAR2(255),
  ZTSRHJ   VARCHAR2(255),
  SJRQ     VARCHAR2(255)
)
tablespace RZRQ
  pctfree 10
  initrans 1
  maxtrans 255
  storage
  (
    initial 64K
    next 1M
    minextents 1
    maxextents unlimited
  );
grant select, insert, update, delete on RZRQ.SC_B13_14120000_Q to KRCS;


spool off
